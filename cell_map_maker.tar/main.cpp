#include <iostream>
#include "map.h"
//instructions:: press n to create new object, 1,2,3,4,0 to switch objecttype, up,down,left,right to change size, left mouse btn to deploy object and right button
//to deploy it and continue constructing objects
int main()
{
	sf::RenderWindow win;
	sf::View view;
	sf::VideoMode desktop = sf::VideoMode().getDesktopMode();
	win.create(desktop, "gen prog");
	win.setFramerateLimit(100);
	win.setKeyRepeatEnabled(true);
	sf::Event event;
	////////////////
	mainhub gamehub;

	while (win.isOpen())
	{
		win.setView(view);
		gamehub.input(win,view,event);
		win.clear(sf::Color(0,0,0));
		gamehub.update(win);
		win.display();
	}

	return 0;
}
