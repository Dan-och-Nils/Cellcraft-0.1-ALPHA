#pragma once
#include <memory>
#include "math.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
//save time and effort of long switch cases by making a dictionary translation between type and texture strings
//fetch namespace contains structural constants and helpfunctions to work with grid,
namespace fetch
{
const int MAP_SIZE_X = 5000;
const int MAP_SIZE_Y = 5000;
const int GRID_SIZE = 50;
const int NODE_MAX = 10000;
inline bool range(auto &target, auto &v1, auto &v2) { return (target >= v1 && target <= v2); }
inline bool range(auto &target, auto &&v1, auto &&v2) { return (target >= v1 && target <= v2); }
auto distance = [](auto &v1, auto &v2) { return sqrt(v1 * v1 + v2 * v2); };
auto mouse_pos_local = [](sf::RenderWindow &window) { return static_cast<sf::Vector2f>(sf::Mouse::getPosition(window)); };
auto mouse_pos_world = [](sf::RenderWindow &window) { return window.mapPixelToCoords(sf::Mouse::getPosition(window)); };
auto grid_id = [](const sf::Vector2f m_pos) {
    int id = (floor)(m_pos.x/GRID_SIZE) + floor(MAP_SIZE_X/GRID_SIZE)*(floor)(m_pos.y/GRID_SIZE);  
    return std::min(std::max(id,0),NODE_MAX); };
auto grid_world = [](const int grid_id) { return sf::Vector2f(GRID_SIZE * (grid_id % (MAP_SIZE_X / GRID_SIZE)), GRID_SIZE * floor(grid_id / (MAP_SIZE_X / GRID_SIZE))); };
std::vector<int> covered_grid_areas(const sf::Vector2f size, const int current_grid)
{
    std::vector<int> grids;

    const int add_horizontal = ceil((int)(size.x - 0.01) / GRID_SIZE);
    const int add_vertical = ceil((int)(size.y - 0.01) / GRID_SIZE);
    for (int i = 0; i <= add_vertical; ++i)
    {
        for (int j = 0; j <= add_horizontal; ++j)
        {
            int grid_id = current_grid + j + (MAP_SIZE_X / GRID_SIZE) * i;
            //if statement represents screen clamping
            if (grid_id >= 0 && grid_id <= NODE_MAX - 1)
            {
                grids.push_back(grid_id);
            }
        }
    }
    return grids;
}
bool screen_clamp_test(const float size_x, const float size_y, const int current_grid)
{ // prevents from building out of the node grid
    const int nodes_x = (MAP_SIZE_X / GRID_SIZE);
    const int nodes_y = (MAP_SIZE_Y / GRID_SIZE);
    const int grid_x = current_grid % nodes_x;
    const int grid_y = (current_grid - grid_x) / (nodes_x);

    const int max_x = grid_x + floor((size_x - 0.01) / GRID_SIZE);
    const int max_y = grid_y + floor((size_y - 0.01) / GRID_SIZE);

    if ((max_x > (nodes_x)-1) || (max_y > (nodes_y)-1))
    {
        return false;
    }
    else
    {
        return true;
    }
}

void setup_grid(std::vector<std::shared_ptr<sf::RectangleShape>> &grid)
{
    for (int y = 0; y < MAP_SIZE_Y / GRID_SIZE; ++y)
    {
        for (int x = 0; x < MAP_SIZE_X / GRID_SIZE; ++x)
        {
            std::shared_ptr<sf::RectangleShape> node = std::make_shared<sf::RectangleShape>();
            node->setPosition(sf::Vector2f(x * GRID_SIZE, y * GRID_SIZE));
            node->setSize(sf::Vector2f(GRID_SIZE, GRID_SIZE));
            node->setFillColor(sf::Color::Green);
            node->setOutlineColor(sf::Color::Black);
            node->setOutlineThickness(5);
            grid.push_back(move(node));
        }
    }
}

const int objects = 4;
//sf::Texture tile;
sf::IntRect tile_area[objects] = {
    sf::IntRect(128, 0, 23, 23),  //background
    sf::IntRect(136, 26, 26, 26), //brick
    sf::IntRect(0, 6, 80, 90),    //house
    sf::IntRect(83, 48, 41, 50)   //tree
};
inline void load_tile(sf::Texture &tile)
{
    if (tile.loadFromFile("tilemap.png"))
    {
        std::cout << "successfully loaded tilemap" << std::endl;
    };
}
int index_tile(const std::string str_in)
{
    if (str_in == "background")
        return 0;
    else if (str_in == "brick")
        return 1;
    else if (str_in == "house")
        return 2;
    else if (str_in == "tree")
        return 3;
    return 42;
}
void set_tile_area()
{
    tile_area[index_tile("background")] = sf::IntRect(128, 0, 23, 23);
    tile_area[index_tile("brick")] = sf::IntRect(136, 26, 26, 26);
    tile_area[index_tile("house")] = sf::IntRect(0, 6, 80, 90);
    tile_area[index_tile("tree")] = sf::IntRect(83, 48, 41, 50);
}
sf::IntRect return_tile(const int type)
{
    return tile_area[type];
}
inline sf::IntRect return_tile(const std::string tiletype)
{
    return tile_area[index_tile(tiletype)];
}
}
//end of namespace//

class mapobjects
{
  public:
    mapobjects() {}
    ~mapobjects() {}
    void set_id_size(const sf::Vector2f size)
    {
        id.setSize(size);
    }
    void set_id_position(const sf::Vector2f pos)
    {
        id.setPosition(pos);
    }
    void update(sf::RenderWindow &window)
    {

        window.draw(id);
    }
    virtual void set_type(const int type) = 0;
    sf::Vector2f get_size()
    {
        return id.getSize();
    }
    sf::Vector2f get_pos()
    {
        return id.getPosition();
    }
    virtual void update_size(const std::string arg)
    {
        float size_x = id.getSize().x;
        float size_y = id.getSize().y;
        if (arg == "size_increase_x")
        {
            id.setSize(sf::Vector2f(size_x + fetch::GRID_SIZE, size_y));
        }
        else if (arg == "size_decrease_x" && floor(size_x / fetch::GRID_SIZE) >= 2)
        {
            id.setSize(sf::Vector2f(size_x - fetch::GRID_SIZE, size_y));
        }
        else if (arg == "size_increase_y")
        {
            id.setSize(sf::Vector2f(size_x, size_y + fetch::GRID_SIZE));
        }
        else if (arg == "size_decrease_y" && floor(size_y / fetch::GRID_SIZE) >= 2)
        {
            id.setSize(sf::Vector2f(size_x, size_y - fetch::GRID_SIZE));
        }
    }

  protected:
    int type;
    sf::Vector2f world_pos;
    sf::RectangleShape id;
    sf::Texture tile;
};

class object_tile : public mapobjects
{
  public:
    object_tile()
    {
    }

    ~object_tile() {}
    object_tile(const int type, const std::string tiletype)
    {
        this->type = type;
        gen_init(tiletype, type);
        id.setTextureRect(fetch::return_tile(tiletype));
    }
    object_tile(sf::Vector2f size, sf::Vector2f pos, const int type, const std::string tiletype)
    {
        std::cout << "created tile : " << tiletype << " with type:" << type << std::endl;
        id.setSize(size);
        id.setPosition(pos);
        this->type = type;
        gen_init(tiletype, type);
    }
    void gen_init(const std::string tiletype, const int type)
    {
        tile.setRepeated(true);
        fetch::load_tile(tile);
        tile.loadFromFile(tiletype);
        id.setTexture(&tile);
        id.setTextureRect(fetch::return_tile(type));
    }
    inline void set_type(const int type)
    {
        this->type = type;
        id.setTextureRect(fetch::return_tile(type));
    }
};

template <typename T>
class mapstorage
{
  public:
    mapstorage()
    {
        init_dummy();
        addto_lib(0, "background.png");
    }
    mapstorage(const std::string filename)
    {
        std::string info;
        init_dummy();

        std::ifstream ost;
        ost.open(filename);
        if (!ost.is_open())
            std::cout << "something went wrong";
        if (ost.peek() == EOF)
        {
            addto_lib(0, "background.png");
        }
        std::string sTemp;
        while (!ost.eof())
        {
            getline(ost, sTemp);
            std::stringstream sst(sTemp);
            float values[4];
            if (sst.str().empty())
            {
                std::cout << "empty string" << std::endl;
                break;
            }
            for (int i = 0; i < 4; ++i)
            {
                while (sst.peek() == ' ')
                {
                    sst.get();
                }
                getline(sst, sTemp, ' ');
                values[i] = std::stoi(sTemp);
            }
            sf::Vector2f size = sf::Vector2f(values[0], values[1]);
            sf::Vector2f pos = fetch::grid_world(values[2]);
            prospect.first = std::make_shared<object_tile>(size, pos, values[3], "tilemap.png");
            prospect.second = values[3]; // per default
            storage.push_back(move(prospect));
            prospect.first = NULL;
        }

        if (storage.empty())
        {
            std::cout << "no objects were added..." << std::endl;
        }
    }
    ~mapstorage()
    {
        std::cout << "saving map" << std::endl;
        std::ofstream fst;
        fst.open("current_level.txt", std::ios::out | std::ios::trunc);
        for (const auto &in : storage)
        {
            sf::Vector2f size = in.first->get_size();
            const int at_grid = fetch::grid_id(in.first->get_pos());
            fst << size.x << " " << size.y << " " << at_grid << " " << in.second << " " << std::endl;
        }
        fst.close();
    }
    mapstorage(std::initializer_list<std::pair<T, int>> init_seq)
    {
        for (const auto in : init_seq)
        {
            storage.push_back(in);
        }
        lib_sort();
        init_dummy();
    }
    void lib_sort()
    {
        auto sort_key = [](std::pair<T, int> t1, std::pair<T, int> t2) { return t1.second < t2.second; };
        std::sort(storage.begin(), storage.end(), sort_key);
    }
    void update(sf::RenderWindow &window)
    {
        mouse_world = fetch::mouse_pos_world(window);
        mouse_local = fetch::mouse_pos_local(window);
        int grid_index = (fetch::grid_id(mouse_world));
        sf::Vector2f grid_converted_cordinate = fetch::grid_world(grid_index);
        if (prospect.first != NULL)
        {
            prospect_occupied = fetch::covered_grid_areas(prospect.first->get_size(), grid_index);
        }
        dummy->setPosition(grid_converted_cordinate);
        if (prospect.first != NULL)
        {
            prospect.first->set_id_position(grid_converted_cordinate);
        }
        for (const auto &in : storage)
        {
            in.first->update(window);           
        }
        if (active_prospect)
        {
            prospect.first->update(window);
        }
        else
        {
            window.draw(*dummy);
        }
    }
    void addto_lib(const int type, const std::string tiletype)
    {
        if (type == 0)
        { //this is a background
            sf::Vector2f tempsize = sf::Vector2f((float)fetch::MAP_SIZE_X, (float)fetch::MAP_SIZE_Y);
            sf::Vector2f temppos = sf::Vector2f(0, 0);
            std::pair<std::shared_ptr<object_tile>, int> mapobject(std::make_shared<object_tile>(tempsize, temppos, type, tiletype), type);
            storage.push_back(move(mapobject));
        }
        else if (fetch::range(type, 1, 10))
        {
            std::shared_ptr<object_tile> mapdummy = std::make_shared<object_tile>();
        }
    }
    void activate_prospect(sf::RenderWindow &window)
    {
        if (!active_prospect)
        {
            active_prospect = true;
            prospect.first = std::make_shared<object_tile>(sf::Vector2f(50, 50), sf::Vector2f(fetch::mouse_pos_world(window)), 1, "tilemap.png");
            prospect.second = 1; // per default
        }
    }
    void update_prototype_size(const std::string arg)
    {
        prospect.first->update_size(arg);
    }
    void init_dummy()
    {
        dummy = std::make_shared<sf::RectangleShape>();
        dummy->setSize(sf::Vector2f(50, 50));
        dummy->setPosition(sf::Vector2f(0, 0));
        dummy->setFillColor(sf::Color::Red);
    }
    void set_prototype_type(const int type)
    {
        prospect.first->set_type(type); // basically just updates texture tile
        prospect.second = type;
    }
    bool create_prototype(const bool repeat)
    {
        if (prospect.first != NULL)
        {
            std::string info;
            sf::Vector2f size = prospect.first->get_size();
            const int current_grid = fetch::grid_id(mouse_world);
            if (!fetch::screen_clamp_test(size.x, size.y, current_grid))
            {
                return false;
            }
            else
            {
                prospect_occupied = fetch::covered_grid_areas(size, current_grid);
                for (const auto &in : prospect_occupied)
                {
                    if (is_grid_occupied(in))
                    {
                        std::cout << "space is occupied, cant deploy struct" << std::endl;
                        return false;
                    }
                }//this doesn't really hold, we need to know what is occupying the area, the index has to have a type occupier saved for this to work

                if (prospect.second != 1 || prospect.second != 0) // we dont classify grass or brick as occupied
                {
                    for (const auto in : prospect_occupied)
                    {
                        occupied.push_back(in);
                    }
                }
                if (repeat == false)
                {
                    storage.push_back(move(prospect));
                    active_prospect = false;
                    prospect.first = NULL;
                }
                if (repeat == true)
                {
                    const int type = prospect.second;
                    const sf::Vector2f pos = prospect.first->get_pos();
                    const sf::Vector2f size = prospect.first->get_size();
                    storage.push_back(move(prospect));
                    prospect.first = NULL;
                    prospect.first = std::make_shared<object_tile>(size, pos, type, "tilemap.png");
                    prospect.second = type;
                }
                return true;
            }
        }
        else
        {
            return false;
        }
    }
    bool is_grid_occupied(const int current_grid)
    {
        for (const auto &in : occupied)
        {
            if (current_grid == in)
            {
                return true;
            }
        }
        return false;
    }

  private:
    sf::Vector2f mouse_world;
    sf::Vector2f mouse_local;
    std::vector<int> prospect_occupied;
    bool active_prospect = false;
    std::pair<std::shared_ptr<mapobjects>, int> prospect;
    std::vector<std::pair<T, int>> storage;
    std::shared_ptr<sf::RectangleShape> dummy = NULL; // this can be a class later, smart use is to create it at selection and allow to move it to storage when selection is final
    std::vector<int> occupied;
};

class input_controller
{
  public:
    input_controller()
    {
    }
    ~input_controller() {}
};

class mainhub
{
  public:
    mainhub()
    {
    }
    ~mainhub() {}
    void input(sf::RenderWindow &window, sf::View &view, sf::Event &event)
    {
        const int fast_update_rate = 10;
        //const int medium_update_rate = 20;
        const int slow_update_rate = 30;

        mouse_scroll(window, view, 10);
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
            }
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
        {
            std::cout << "exited through escape key" << std::endl;
            window.close();
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::N))
        {
            m_storage.activate_prospect(window);
            menu_state = 1;
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num0) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.set_prototype_type(0);
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num1) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.set_prototype_type(1);
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num2) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.set_prototype_type(2);
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num3) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.set_prototype_type(3);
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.update_prototype_size("size_decrease_x");
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.update_prototype_size("size_increase_x");
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.update_prototype_size("size_increase_y");
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && regulate_timer(fast_update_rate) && menu_state == 1)
        {
            m_storage.update_prototype_size("size_decrease_y");
        }
        else if (sf::Mouse::isButtonPressed(sf::Mouse::Left) && regulate_timer(slow_update_rate) && menu_state == 1)
        {
            if (m_storage.create_prototype(false))
            {
                menu_state = 0;
            }
            else
            {
                std::cout << "unable to create object" << std::endl;
            }
        }
        else if (sf::Mouse::isButtonPressed(sf::Mouse::Right) && regulate_timer(fast_update_rate) && menu_state == 1) //make more!
        {
            if (m_storage.create_prototype(true))
            {
                //....
            }
            else
            {
                std::cout << "unable to create object" << std::endl;
            }
        }
    }
    bool regulate_timer(const int button_spam_controller)
    {
        if (timer >= button_spam_controller)
        {
            timer = 0;
            return true;
        }
        else
        {
            return false;
        }
    }
    void update(sf::RenderWindow &window)
    {
        ++timer;
        m_storage.update(window);
    }
    void mouse_scroll(sf::RenderWindow &window, sf::View &view, const float scrollspeed)
    {
        sf::Vector2f win_pos = static_cast<sf::Vector2f>(sf::Mouse::getPosition(window));
        if (win_pos.x <= 5)
        {
            view.move(sf::Vector2f({-scrollspeed, 0}));
        }
        else if (win_pos.x >= 1850)
        {
            view.move(sf::Vector2f({scrollspeed, 0}));
        }
        else if (win_pos.y <= 5)
        {
            view.move(sf::Vector2f({0, -scrollspeed}));
        }
        else if (win_pos.y >= 1000)
            view.move(sf::Vector2f({0, scrollspeed}));
        }
    }

  private:
    mapstorage<std::shared_ptr<mapobjects>> m_storage{"current_level.txt"};
    int timer = 0;
    int menu_state = 0; // 1 = prospect building
};

class menu_lib{
public:
menu_lib() = default;
~menu_lib() = default;

private :

menu_options[3] = {
    4,
    4,
    4
};
Font menu_font;
float option_spacing;
const int font_size = 15;


};
